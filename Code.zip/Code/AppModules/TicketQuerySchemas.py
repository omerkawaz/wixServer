from marshmallow import Schema, fields


class TicketGetQuerySchema(Schema):
    id = fields.Str(required=True)
    
