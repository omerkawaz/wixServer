SQLALCHEMY_DATABASE_URI =  "sqlite:///DB.db"
db_path = "instance//DB.db"
