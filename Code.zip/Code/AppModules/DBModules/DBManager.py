from flask import Flask, abort
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql.expression import ColumnOperators, or_
from typing import List
import json
from os import path


class DBManager():
    
    def __init__(self,flask_app: Flask, db: SQLAlchemy, json_db_path: str = None) -> None:
        """Constructs a new DBManager Object

        :param flask_app: An initialized flask application.
        :param db: An initialized SQLAlchemy database which was initialized with flask_app.
        :param json_db_path: Optional. A path string to point to the location of json db files to load to db.
        """
        self.db = db
        self.app = flask_app
        self.models = {}
        self.page_size = 20
        
        # could not be sepearated to different file because it depends on member self.db after it's initialization
        class Ticket(db.Model):
            id = db.Column(db.String, primary_key=True, unique=True, nullable=False)
            title = db.Column(db.String(200), unique=False, nullable=False)
            content = db.Column(db.String(10000), unique=False, nullable=False)
            userEmail = db.Column(db.String(200), unique=False, nullable=False)
            creationTime = db.Column(db.BigInteger, unique=False, nullable=False)
            
            def __init__(self, id = None, title = "Null", content = "Null", userEmail = "Null", creationTime= -1):
                self.id = id
                self.title = title
                self.content = content
                self.userEmail = userEmail
                self.creationTime = creationTime
                
            
            def __repr__(self):
                return '<Ticket %r>' % self.id
            
        self.ticketModel=Ticket
            
        with self.app.app_context():
            self.db.create_all()
        if json_db_path is not None:
            self.__init_db_from_json_file__(json_db_path)

    def __init_db_from_json_file__(self, json_db_path: str):
        print("json db path is: " + json_db_path)
        if not path.exists(json_db_path):
            print("no db file found")
            return False
        with self.app.app_context():
            with open(json_db_path) as json_db_file:
                ticket_db_dict_object = json.load(json_db_file)
                for ticket_dict_object in ticket_db_dict_object:
                    print(ticket_dict_object)
                    ticket = self.ticketModel(**ticket_dict_object)
                    self.db.session.add(ticket)
                self.db.session.commit()
                
    
    def get_all_table_keys(self):
        return list(self.db.metadata.tables.keys())
    
    def get_row_count(self):
        with self.app.app_context():
            row_count = 0
            for table in self.get_all_table_keys():
                row_count = row_count + self.db.session.query(self.models[table]).count()
            return row_count
    
    def get_db_models(self):
        return self.models
            
    def get_ticket(self, ticket):
        with self.app.app_context():
            return self.db.get_or_404(self.ticketModel, ticket.id, description="Ticket id not found")
        
    def get_ticket_page(self, page_num):
        with self.app.app_context():
            return self.ticketModel.query.order_by(self.ticketModel.creationTime.asc()).paginate(page=page_num, per_page=self.page_size)
            
            
    def get_tickets_filtered_by_title(self, relevant_text: str, page_num:int = None):
        if page_num is None:
            page_num = 0
        with self.app.app_context():
            self.ticketModel.query.order_by(self.ticketModel.creationTime.asc()).filter_by(self.ticketModel.title.contains(relevant_text)).paginate(page=page_num, per_page=self.page_size)
            
    def get_tickets_filtered_by_time(self, oldest_ticket_time, newest_ticket_time, page_num:int = None):
        if page_num is None:
            page_num = 0
        with self.app.app_context():
            query = self.ticketModel.query.order_by(self.ticketModel.creationTime.asc())
            if oldest_ticket_time is not None:
                query.filter_by(self.ticketModel.creationTime>oldest_ticket_time)
            if newest_ticket_time is not None:
                query.filter_by(self.ticketModel.creationTime<newest_ticket_time)
            query.paginate(page=page_num, per_page=self.page_size)
            
            
    def get_tickets_filtered_by_all_text_fields(self, relevant_text: str, page_num:int = None):
        if page_num is None:
            page_num = 0
        with self.app.app_context():
            self.ticketModel.query.order_by(self.ticketModel.creationTime.asc()).filter_by
            (or_(self.ticketModel.title.contains(relevant_text),
                 self.ticketModel.userEmail.contains(relevant_text), 
                 self.ticketModel.content.contains(relevant_text))).paginate(page=page_num, per_page=self.page_size)
            

     

