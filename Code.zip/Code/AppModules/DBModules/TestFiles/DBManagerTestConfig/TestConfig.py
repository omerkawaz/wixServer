import json

json_db_path = 'TestFiles//DBManagerTestConfig//Database//data.json'
db_size = 200



example_ticket = {"id": "81a885d6-8f68-5bc0-bbbc-1c7b32e4b4e4"}
nonexisting_ticket = {"id": "fake_id"}