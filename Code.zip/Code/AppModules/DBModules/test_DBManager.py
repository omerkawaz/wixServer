import unittest
from DBManager import DBManager
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError
from flask import Flask
from werkzeug.exceptions import HTTPException
from builtins import dict
import json
import sqlite3
import os

from TestFiles.DBManagerTestConfig import FlaskConfig
from TestFiles.DBManagerTestConfig import TestConfig


unittest.TestLoader.sortTestMethodsUsing = None

#clear previous database if exists
if os.path.exists(FlaskConfig.db_path):
    os.remove(FlaskConfig.db_path)

# initialize flask_app
flask_app = Flask(__name__)
flask_app.config.from_pyfile("TestFiles//DBManagerTestConfig//FlaskConfig.py")
db_manager = DBManager(flask_app, SQLAlchemy(flask_app))


class Test_DBManager(unittest.TestCase):
    
    # Naming the tests with test_# is required to keep order execution order correct
    def test_db_init(self):
        db_manager.__init_db_from_json_file__(TestConfig.json_db_path)
        expected_tables = ['ticket']
        self.assertEqual(db_manager.get_all_table_keys(), expected_tables) # expect preloaded tables
        self.assertEqual(db_manager.get_row_count(), TestConfig.db_size)
    
    
    def test_get_ticket(self):
        ticket_id_data = TestConfig.perfect_ticket
        ticket = db_manager.get_ticket(db_manager.ticketModel(**ticket_id_data))
        self.assertEqual(ticket.id, ticket_id_data['id'])
        
        
    def test_get_nonexisting_ticket(self):
        ticket_id_data = TestConfig.nonexisting_ticket
        try:
            ticket = db_manager.get_ticket(db_manager.ticketModel(**ticket_id_data))
        except HTTPException as exc:
            self.assertEqual(exc.code, 404)
            return
        self.assertFalse(True, msg="Exception should raise, id does not exist.")
        
        
        
    def test_get_page(self):
        ticket_id_data = TestConfig.nonexisting_ticket
        try:
            ticket = db_manager.get_ticket(db_manager.ticketModel(**ticket_id_data))
        except HTTPException as exc:
            self.assertEqual(exc.code, 404)
            return
        self.assertFalse(True, msg="Exception should raise, id does not exist.")
        
        
        
        
    # def test_2_add_ticket_with_no_gpa(self):
    #     new_ticket_data = TestConfig.no_gpa_ticket
    #     new_ticket = db_manager.get_db_models()['ticket'](**new_ticket_data)
    #     db_manager.add_ticket(new_ticket)
        
    #     fetched_ticket = db_manager.get_ticket(new_ticket_data['id_num'])
    #     self.assertEqual(fetched_ticket.id_num, new_ticket_data['id_num'])
    #     self.assertEqual(fetched_ticket.username, new_ticket_data['username'])
    #     self.assertEqual(fetched_ticket.email, new_ticket_data['email'])
    #     self.assertEqual(fetched_ticket.gpa, 0)  
        
        
    # def test_6_get_tickets_by_range(self):
    #     more_tickets = TestConfig.more_tickets
    #     for new_ticket_data in more_tickets:
    #         new_ticket = db_manager.get_db_models()['ticket'](**new_ticket_data)
    #         db_manager.add_ticket(new_ticket)
        
    #     id_range = TestConfig.id_range
    #     fetched_tickets = db_manager.get_tickets_by_id_range(id_range['low_id'], id_range['high_id'])
    #     received_ids = []
    #     for ticket in fetched_tickets:
    #         received_ids.append(ticket.id_num)
        
    #     self.assertEqual(received_ids, TestConfig.filtered_ids)    
        

if __name__ == "__main__":
    unittest.main()