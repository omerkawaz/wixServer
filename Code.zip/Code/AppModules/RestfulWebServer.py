from flask import Flask, abort, jsonify
from flask_restful import Api, Resource, request
from .DBModules.DBManager import DBManager
from .Config import AppConfig
from .TicketQuerySchemas import *

import json

class RestfulWebServer():
    def __init__(self, flask_config_path="Config/FlaskConfig.py", json_db_path: str = AppConfig.json_db_path):
        self.app = Flask(__name__)
        self.app.config.from_pyfile(flask_config_path)
        self.db = DBManager(self.app, json_db_path)
        
        @self.app.route("/tickets", methods=['GET'])
        def get():
            if request.method != ['GET']:
                abort(404, "Only Get Requests are approved in this endpoint")
            
            # Fetch single ticket from server
            if request.args.get('ticket_id') is not None:
                ticket_id = request.args.get('ticket_id')
                return self.db.get_ticket(ticket_id)
            
            # Fetch tickets containing relevant text in titles
            elif request.args.get('search_in_titles'):
                relevant_text = request.args.get('search_in_titles')
                page_num = request.args.get('page_num')
                return self.db.get_tickets_filtered_by_title(relevant_text, page_num)
            
            # Fetch tickets according to time range
            elif request.args.get('oldest_ticket_time') or request.args.get('newest_ticket_time'):
                page_num = request.args.get('page_num')
                oldest_ticket_time = request.args.get('oldest_ticket_time')
                newest_ticket_time = request.args.get('newest_ticket_time')
                return self.db.get_tickets_filtered_by_time(oldest_ticket_time, newest_ticket_time, page_num)
            
            # Fetch tickets containing relevant text in all text fields
            elif request.args.get('filter_by_all_text_fields'):
                page_num = request.args.get('page_num')
                return self.db.get_tickets_filtered_by_all_text_fields(oldest_ticket_time, newest_ticket_time, page_num)
            
            # Fetch a certain page of tickets
            elif request.args.get('page_num'):
                page_num = request.args.get('page_num')
                return self.db.get_ticket_page(page_num)
         
            
    def run(self, _port=5000):
        self.app.run(port=_port, debug=True)
        
    
                