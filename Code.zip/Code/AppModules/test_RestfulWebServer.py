import unittest
from flask_sqlalchemy import SQLAlchemy
from flask import Flask
from werkzeug.exceptions import HTTPException
import os
from RestfulWebServer import RestfulWebServer

from TestFiles.RestfulWebServerTestConfig import FlaskConfig
from TestFiles.RestfulWebServerTestConfig import TestConfig

#clear previous database if exists
if os.path.exists(FlaskConfig.db_path):
    os.remove(FlaskConfig.db_path)

RestfulWebServer(flask_config_path=TestConfig.FLASK_CONFIG_PATH)

class Test_RestfulWebServer(unittest.TestCase):
    
    # Naming the tests with test_# is required to keep order execution order correct
    def test_0_empty_db_init(self):
        expected_tables = ['student', 'class']
        self.assertEqual(db_manager.get_all_table_keys(), expected_tables) # expect preloaded tables
        self.assertEqual(db_manager.get_row_count(), 0) # expect those tables to be empty
        self.assertEqual(list(db_manager.get_db_models().keys()), db_manager.get_all_table_keys()) # expect known models to be same as tables
        
    def test_1_add_get_student(self):
        new_student_data = TestConfig.perfect_student
        new_student = db_manager.get_db_models()['student'](**new_student_data)
        db_manager.add_student(new_student)
        
        fetched_student = db_manager.get_student(new_student_data['id_num'])
        self.assertEqual(fetched_student.id_num, new_student_data['id_num'])
        self.assertEqual(fetched_student.username, new_student_data['username'])
        self.assertEqual(fetched_student.email, new_student_data['email'])
        self.assertEqual(fetched_student.gpa, new_student_data['gpa'])
        
    def test_2_add_student_with_no_gpa(self):
        new_student_data = TestConfig.no_gpa_student
        new_student = db_manager.get_db_models()['student'](**new_student_data)
        db_manager.add_student(new_student)
        
        fetched_student = db_manager.get_student(new_student_data['id_num'])
        self.assertEqual(fetched_student.id_num, new_student_data['id_num'])
        self.assertEqual(fetched_student.username, new_student_data['username'])
        self.assertEqual(fetched_student.email, new_student_data['email'])
        self.assertEqual(fetched_student.gpa, 0)
        
    def test_3_add_student_with_no_email(self):
        # expect student with no email to not be added.
        new_student_data = TestConfig.no_email_student
        new_student = db_manager.get_db_models()['student'](**new_student_data)
        try:
            db_manager.add_student(new_student)
        except HTTPException as exc:
            self.assertEqual(exc.code, 404)
            return
        self.assertFalse(True, "An IntegrityError shouldv'e been raised as email in mandatory.")
        
        
    def test_4_remove_student(self):
        student_to_remove = TestConfig.no_gpa_student
        db_manager.remove_student(student_to_remove['id_num'])
        
        
    def test_5_remove_nonexisting_student(self):
        student_to_remove = TestConfig.fake_student
        try:
            db_manager.remove_student(student_to_remove['id_num'])
        except HTTPException as exc:
            self.assertEqual(exc.code, 404)
            return
        
        self.assertFalse(True, "A HTTPException shouldv'e been raised as user does not exist.")
        
        
    def test_6_get_students_by_range(self):
        more_students = TestConfig.more_students
        for new_student_data in more_students:
            new_student = db_manager.get_db_models()['student'](**new_student_data)
            db_manager.add_student(new_student)
        
        id_range = TestConfig.id_range
        fetched_students = db_manager.get_students_by_id_range(id_range['low_id'], id_range['high_id'])
        received_ids = []
        for student in fetched_students:
            received_ids.append(student.id_num)
        
        self.assertEqual(received_ids, TestConfig.filtered_ids)    
        

if __name__ == "__main__":
    unittest.main()