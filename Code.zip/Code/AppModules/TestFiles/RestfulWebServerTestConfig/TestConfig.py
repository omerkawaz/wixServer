
FLASK_CONFIG_PATH = "TestFiles//RestfulWebServerTestConfig//FlaskConfig.py"

perfect_student = {'id_num': 10, 'username': "omerkawaz", 'email': "omerkawaz@wix.com", 'gpa': 100}
no_gpa_student = {'id_num': 11, 'username': "yonicohen", 'email': "yonicohen@wix.com"}
no_email_student = {'id_num': 12, 'username': "adamlevi"}
fake_student = {'id_num': 13, 'username': "abrahamlincoln", 'email': "abrahamlincoln@wiz.com", 'gpa': 100}
id_range = {'low_id': 22, 'high_id': 27}
more_students = [
    {'id_num': 20, 'username': "person20", 'email': "person20@wix.com", 'gpa': 100},
    {'id_num': 21, 'username': "person21", 'email': "person21@wix.com", 'gpa': 100},
    {'id_num': 22, 'username': "person22", 'email': "person22@wix.com", 'gpa': 100},
    {'id_num': 23, 'username': "person23", 'email': "person23@wix.com", 'gpa': 100},
    {'id_num': 24, 'username': "person24", 'email': "person24@wix.com", 'gpa': 100},
    {'id_num': 25, 'username': "person25", 'email': "person25@wix.com", 'gpa': 100},
    {'id_num': 26, 'username': "person26", 'email': "person26@wix.com", 'gpa': 100},
    {'id_num': 27, 'username': "person27", 'email': "person27@wix.com", 'gpa': 100},
    {'id_num': 28, 'username': "person28", 'email': "person28@wix.com", 'gpa': 100},
    {'id_num': 29, 'username': "person29", 'email': "person29@wix.com", 'gpa': 100}
]
filtered_ids = [22,23,24,25,26,27]