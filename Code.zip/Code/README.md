# Introduction
This project was written as a part of the 'Wix Kickstart' program.
the goal of the project is to manage a ticketing system.
it implements both a Web server and a database manager, allowing for easy actions
regarding ticket fetching with various filters.

## Requirements
First of all you have the latest version of python installed.
Second, i strongly recommend you set up a virtualenv, if you do not
know what a virtual environment you can read all about it here: https://docs.python.org/3/library/venv.html
now we can install all of the requirements for this project using the command:
 ```pip install -r requirements.txt```

## How to run
cd to the base directory where the project was extracted, and run: ```python main.py```

## a word if i may
The project does not run at the moment.
Python is not my native language as i mostly code in C++ yet i tried my best!
i hope you find my overall work pleasing.
have a nice rest of your day and thank you for your time!