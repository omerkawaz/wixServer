from AppModules.RestfulWebServer import RestfulWebServer

if __name__ == "__main__":
    server = RestfulWebServer()
    server.run()